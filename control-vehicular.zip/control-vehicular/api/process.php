<?php
require_once '../includes/functions.php';

header('Content-Type: application/json');

$action = $_GET['action'] ?? '';

switch ($action) {
    case 'list_vehiculos':
        echo json_encode(obtenerVehiculos($pdo));
        break;

    case 'list_deudas':
        $patente = $_GET['patente'] ?? '';
        echo json_encode(obtenerDeudasPorVehiculo($pdo, $patente));
        break;

    case 'add_vehiculo':
        $data = json_decode(file_get_contents('php://input'), true);
        if (isset($data['patente'], $data['modelo'])) {
            $status = agregarVehiculo($pdo, $data['patente'], $data['modelo']);
            echo json_encode(['success' => $status]);
        } else {
            echo json_encode(['success' => false, 'message' => 'Datos incompletos']);
        }
        break;

    case 'delete_vehiculo':
        $data = json_decode(file_get_contents('php://input'), true);
        if (isset($data['patente'])) {
            $status = eliminarVehiculo($pdo, $data['patente']);
            echo json_encode(['success' => $status]);
        } else {
            echo json_encode(['success' => false]);
        }
        break;

    case 'add_deuda':
        $data = json_decode(file_get_contents('php://input'), true);
        if (isset($data['patente'], $data['monto'], $data['motivo'], $data['fecha'])) {
            $status = registrarDeuda($pdo, $data['patente'], $data['monto'], $data['motivo'], $data['fecha']);
            echo json_encode(['success' => $status]);
        } else {
            echo json_encode(['success' => false, 'message' => 'Datos incompletos']);
        }
        break;

    default:
        echo json_encode(['error' => 'Acción no válida']);
        break;
}