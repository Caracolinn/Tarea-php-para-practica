<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Control Vehicular Municipal</title>
    <style>
        body { font-family: Arial, sans-serif; margin: 30px; background-color: #f4f6f9; color: #333; }
        .container { display: flex; gap: 20px; }
        .box { background: white; padding: 20px; border-radius: 8px; box-shadow: 0 2px 5px rgba(0,0,0,0.1); flex: 1; }
        h2 { color: #0056b3; margin-top: 0; }
        table { width: 100%; border-collapse: collapse; margin-top: 15px; }
        th, td { border: 1px solid #ddd; padding: 10px; text-align: left; }
        th { background-color: #f2f2f2; }
        .form-group { margin-bottom: 15px; }
        label { display: block; margin-bottom: 5px; font-weight: bold; }
        input { width: 100%; padding: 8px; box-sizing: border-box; border: 1px solid #ccc; border-radius: 4px; }
        button { background-color: #007bff; color: white; border: none; padding: 10px 15px; border-radius: 4px; cursor: pointer; }
        button:hover { background-color: #0056b3; }
        button.btn-danger { background-color: #dc3545; }
        button.btn-danger:hover { background-color: #bd2130; }
        .btn-view { background-color: #28a745; margin-right: 5px; }
        .btn-view:hover { background-color: #218838; }
    </style>
</head>
<body>

    <h1>Sistema de Control Vehicular - Comuna</h1>
    <hr>

    <div class="container">
        <div class="box">
            <h2>Vehículos Registrados</h2>
            <div style="margin-bottom: 20px; padding: 10px; background: #e9ecef; border-radius: 4px;">
                <h3>Agregar Vehículo</h3>
                <div class="form-group">
                    <label for="patente">Patente:</label>
                    <input type="text" id="patente" placeholder="Ej: BBCC11" maxlength="10">
                </div>
                <div class="form-group">
                    <label for="modelo">Modelo:</label>
                    <input type="text" id="modelo" placeholder="Ej: Toyota Yaris">
                </div>
                <button onclick="guardarVehiculo()">Registrar Vehículo</button>
            </div>

            <table>
                <thead>
                    <tr>
                        <th>Patente</th>
                        <th>Modelo</th>
                        <th>Acciones</th>
                    </tr>
                </thead>
                <tbody id="tabla-vehiculos"></tbody>
            </table>
        </div>

        <div class="box">
            <h2>Deudas del Vehículo: <span id="vehiculo-seleccionado" style="color:#dc3545;">Ninguno</span></h2>
            <table>
                <thead>
                    <tr>
                        <th>ID</th>
                        <th>Motivo</th>
                        <th>Monto</th>
                        <th>Fecha Emisión</th>
                    </tr>
                </thead>
                <tbody id="tabla-deudas">
                    <tr>
                        <td colspan="4" style="text-align: center; color: #777;">Selecciona un vehículo para ver sus deudas</td>
                    </tr>
                </tbody>
            </table>
        </div>
    </div>

    <script>
        const API_URL = '../api/process.php';

        async function cargarVehiculos() {
            try {
                const res = await fetch(`${API_URL}?action=list_vehiculos`);
                const vehiculos = await res.json();
                const tbody = document.getElementById('tabla-vehiculos');
                tbody.innerHTML = '';

                vehiculos.forEach(v => {
                    tbody.innerHTML += `
                        <tr>
                            <td><strong>${v.patente}</strong></td>
                            <td>${v.modelo}</td>
                            <td>
                                <button class="btn-view" onclick="verDeudas('${v.patente}')">Ver Deudas</button>
                                <button class="btn-danger" onclick="eliminarVehiculo('${v.patente}')">Eliminar</button>
                            </td>
                        </tr>
                    `;
                });
            } catch (error) {
                console.error("Error al cargar vehículos:", error);
            }
        }

        async function verDeudas(patente) {
            document.getElementById('vehiculo-seleccionado').innerText = patente;
            try {
                const res = await fetch(`${API_URL}?action=list_deudas&patente=${patente}`);
                const deudas = await res.json();
                const tbody = document.getElementById('tabla-deudas');
                tbody.innerHTML = '';

                if (deudas.length === 0) {
                    tbody.innerHTML = `<tr><td colspan="4" style="text-align: center; color: green;">No registra deudas pendientes.</td></tr>`;
                    return;
                }

                deudas.forEach(d => {
                    tbody.innerHTML += `
                        <tr>
                            <td>${d.id}</td>
                            <td>${d.motivo}</td>
                            <td>$${parseInt(d.monto).toLocaleString('es-CL')}</td>
                            <td>${d.fecha_emision}</td>
                        </tr>
                    `;
                });
            } catch (error) {
                console.error("Error al cargar deudas:", error);
            }
        }

        async function guardarVehiculo() {
            const patente = document.getElementById('patente').value.trim();
            const modelo = document.getElementById('modelo').value.trim();

            if (!patente || !modelo) {
                alert("Por favor, rellena todos los campos.");
                return;
            }

            try {
                const res = await fetch(`${API_URL}?action=add_vehiculo`, {
                    method: 'POST',
                    headers: { 'Content-Type': 'application/json' },
                    body: JSON.stringify({ patente, modelo })
                });
                
                const resultado = await res.json();
                if (resultado.success) {
                    document.getElementById('patente').value = '';
                    document.getElementById('modelo').value = '';
                    cargarVehiculos();
                } else {
                    alert("Error al registrar: Puede que la patente ya exista.");
                }
            } catch (error) {
                console.error("Error al guardar:", error);
            }
        }

        async function eliminarVehiculo(patente) {
            if (!confirm(`¿Está seguro de eliminar el vehículo ${patente}? Esto borrará también todas sus deudas.`)) {
                return;
            }

            try {
                const res = await fetch(`${API_URL}?action=delete_vehiculo`, {
                    method: 'POST',
                    headers: { 'Content-Type': 'application/json' },
                    body: JSON.stringify({ patente })
                });

                const resultado = await res.json();
                if (resultado.success) {
                    cargarVehiculos();
                    if (document.getElementById('vehiculo-seleccionado').innerText === patente) {
                        document.getElementById('vehiculo-seleccionado').innerText = 'Ninguno';
                        document.getElementById('tabla-deudas').innerHTML = `<tr><td colspan="4" style="text-align: center; color: #777;">Selecciona un vehículo para ver sus deudas</td></tr>`;
                    }
                }
            } catch (error) {
                console.error("Error al eliminar:", error);
            }
        }

        window.onload = cargarVehiculos;
    </script>
</body>
</html>