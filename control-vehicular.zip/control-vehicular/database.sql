
CREATE DATABASE IF NOT EXISTS control_transito CHARACTER SET utf8 COLLATE utf8_general_ci;
USE control_transito;

DROP TABLE IF EXISTS deudas;
DROP TABLE IF EXISTS vehiculos;

CREATE TABLE vehiculos (
    patente VARCHAR(10) NOT NULL,
    modelo VARCHAR(50) NOT NULL,
    PRIMARY KEY (patente)
) ENGINE=InnoDB;

CREATE TABLE deudas (
    id INT AUTO_INCREMENT NOT NULL,
    patente VARCHAR(10) NOT NULL,
    monto INT NOT NULL,
    motivo VARCHAR(255) NOT NULL,
    fecha_emision DATE NOT NULL,
    PRIMARY KEY (id),
    CONSTRAINT fk_deudas_vehiculos
    FOREIGN KEY (patente) REFERENCES vehiculos(patente) 
    ON DELETE CASCADE 
    ON UPDATE CASCADE
) ENGINE=InnoDB;

INSERT INTO vehiculos (patente, modelo) VALUES 
('BBCC11', 'Toyota Yaris'),
('DDEE22', 'Hyundai Accent'),
('FFGG33', 'Suzuki Swift'),
('HHII44', 'Mazda 3'),
('JJKK55', 'Chevrolet Sail');

INSERT INTO deudas (patente, monto, motivo, fecha_emision) VALUES 
('BBCC11', 45000, 'Exceso de velocidad en zona urbana', '2026-03-15'),
('BBCC11', 12500, 'No pago de TAG diario obligatorio', '2026-04-02'),
('DDEE22', 60000, 'Estacionar en sitio prohibido o señalizado', '2026-04-10'),
('FFGG33', 35000, 'Conducir hablando por teléfono celular', '2026-05-01'),
('HHII44', 18000, 'Tag tardío acumulado', '2026-05-18');