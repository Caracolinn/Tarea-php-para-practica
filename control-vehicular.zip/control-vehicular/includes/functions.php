<?php
require_once __DIR__ . '/../config/database.php';  // Asegura que la conexión a la base de datos esté disponible para las funciones

function obtenerVehiculos($pdo) { 
    return $pdo->query("SELECT * FROM vehiculos")->fetchAll();
}

function obtenerDeudasPorVehiculo($pdo, $patente) {
    $stmt = $pdo->prepare("SELECT * FROM deudas WHERE patente = ?"); // Consulta preparada para evitar inyección SQL
    $stmt->execute([$patente]);
    return $stmt->fetchAll();
}

function agregarVehiculo($pdo, $patente, $modelo) {
    try {
        $stmt = $pdo->prepare("INSERT INTO vehiculos (patente, modelo) VALUES (?, ?)"); // Consulta preparada para evitar inyección SQL
        return $stmt->execute([$patente, $modelo]);
    } catch (PDOException $e) {
        return false; // Falla si la patente ya existe
    }
}

function eliminarVehiculo($pdo, $patente) {
    $stmt = $pdo->prepare("DELETE FROM vehiculos WHERE patente = ?"); // Consulta preparada para evitar inyección SQL
    return $stmt->execute([$patente]);
}

function registrarDeuda($pdo, $patente, $monto, $motivo, $fecha) {
    $stmt = $pdo->prepare("INSERT INTO deudas (patente, monto, motivo, fecha_emision) VALUES (?, ?, ?, ?)"); // Consulta preparada para evitar inyección SQL
    return $stmt->execute([$patente, $monto, $motivo, $fecha]);
}